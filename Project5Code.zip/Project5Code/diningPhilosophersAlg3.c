#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
//#include <semaphore.h>

#include "common.h"
#include "common_threads.h"
#include "zemaphore.h"

Zem_t forks[20];
int philosophers;
Zem_t table;

int left(int p) {return p;}
int right(int p) {return (p+1)%philosophers;}


void GetForks(int p) 
{
    Zem_wait(&forks[right(p)]);
    Zem_wait(&forks[left(p)]);
}


void PutForks(int p)
{
    Zem_post(&forks[right(p)]);
    Zem_post(&forks[left(p)]);
}

void GetTable() {
    Zem_wait(&table);
}

void LeaveTable() {
    Zem_post(&table);
}


void* DiningPhilosopher(void* arg) 
{
    long long int value = (long long int) arg;
    int p = (int)value;
    while (1)
    {
        sleep(1);
        printf("Philosopher %d thinking \n", p);
        GetTable();
        printf("Philosopher %d gets table\n", p);
        GetForks(p); 
        printf("Philosopher %d picking up forks \n", p);
        sleep(1);
        printf("Philosopher %d eating \n", p);
        PutForks(p);
        printf("Philosopher %d putting down forks \n", p);
        LeaveTable();
        printf("Philosopher %d leaves table \n",p);

    }
    return NULL;
}



int main(int argc, char *argv[]) 
{

    printf("How many philosophers? \n");
    scanf("%d", &philosophers);
    for (int i = 0; i < philosophers; i++){
        Zem_init(&forks[i],1);
        
    }
    Zem_init(&table, philosophers-1);

    pthread_t c;
    printf("parent: begin\n");
    for (int j = 0; j < philosophers; ++j)
    {
        long long int me = j;
        Pthread_create(&c, NULL, DiningPhilosopher, (void*)me);
    }
    Pthread_join(c, NULL);
    return 0;
}