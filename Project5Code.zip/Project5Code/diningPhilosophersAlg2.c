#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
//#include <semaphore.h>

#include "common.h"
#include "common_threads.h"
#include "zemaphore.h"

Zem_t forks[20];
Zem_t mutex;
int philosophers;
int forksAvailable[20];

int left(int p) {return p;}
int right(int p) {return (p+1)%philosophers;}


void GetForks(int p) 
{
    if (forksAvailable[left(p)] == 1 && forksAvailable[right(p)] == 1){
        Zem_wait(&forks[left(p)]);
        Zem_wait(&forks[right(p)]);
    }
}


void PutForks(int p)
{
    Zem_post(&forks[left(p)]);
    Zem_post(&forks[right(p)]);
}


void* DiningPhilosopher(void* arg) 
{
    long long int value = (long long int) arg;
    int p = (int)value;
    while (1)
    {
        printf("Philosophers thinking \n");
        sleep(1);
        printf("Philosophers picking up forks \n");
        GetForks(p); 
        printf("Philosophers eating \n");
        sleep(1);
        printf("Philosophers putting down forks \n");
        PutForks(p);
    }
    return NULL;
}



int main(int argc, char *argv[]) 
{

    printf("How many philosophers? \n");
    scanf("%d", &philosophers);
    for (int i = 0; i < philosophers; i++){
        Zem_init(&forks[i],1);
        forksAvailable[i] = 1;
    }


    pthread_t c;
    printf("parent: begin\n");
    for (int j = 0; j < philosophers; ++j)
    {
        long long int me = j;
        Pthread_create(&c, NULL, DiningPhilosopher, (void*)me);
    }
    Pthread_join(c, NULL);
    return 0;
}