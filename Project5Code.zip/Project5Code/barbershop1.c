#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
//#include <semaphore.h>

#include "common.h"
#include "common_threads.h"
#include "zemaphore.h"

Zem_t chairs;
Zem_t mutex;
int barbers;
Zem_t working;

void haircut() {
    sleep(1);
    Zem_post(&working);
}


void* BarberShopBarber() {
    while(1) {
        if(barbers > 0) {
            sleep(1);
        }
        else {
            haircut();
        }
    }
}

void haircutCustomer(int customer) {
    Zem_wait(&working);
    sleep(1);
    barbers++;
    printf("Customer number %d is getting a haircut \n", customer);
}

void* BarberShopCustomer(void* arg) {
    long long int i = (long long int)arg;
    int customer = (int)i;

    //Barber Chair = 0 when all are taken
    if(barbers == 0) {
        Zem_wait(&chairs);
        printf("Customer number %d is in a chair \n", customer);


        while(barbers == 0)
        {
            
        }

        Zem_wait(&mutex);

        printf("Customer number %d is now in a barber's chair.\n", customer);
        barbers--;
        Zem_post(&chairs);
        haircutCustomer(customer);
        Zem_post(&mutex);
    }
    else {
        Zem_wait(&mutex);
        barbers--;
        printf("Customer number %d is now in a barber's chair.\n", customer);

        haircutCustomer(customer);
        Zem_post(&mutex);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    int count = 5;
    barbers = 2;
    printf("How many chairs? \n");
    scanf("%d", &count);
    Zem_init(&chairs, count);
    
    Zem_init(&mutex, barbers);
    Zem_init(&working, 0);

    int customers = 10;
    pthread_t b;

    for(int i = 0; i < barbers; i++) {
        Pthread_create(&b, NULL, BarberShopBarber, 0);
    }

    pthread_t c;
    for (int j = 0; j < customers; ++j) {
        long long int me = j;
        Pthread_create(&c, NULL, BarberShopCustomer, (void*)me);
    }

    Pthread_join(c, NULL);
    Pthread_join(b, NULL);

    return 0;
}